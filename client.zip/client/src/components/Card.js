import React, { useEffect, useState } from 'react'
import data from './CardData'
//import { Link } from 'react-router-dom';

function Card() {

const [arrayData,setArrayData] = useState([])
let i =0;

useEffect(() => {
    const setIntFunc = setInterval(() => {
      let array = [];

      array.push(data[i], data[i + 1], data[i + 2], data[i + 3]);

      setArrayData(array);

      array = [];
      if (i === 6) {
        i = 0;
      } else {
        i++;
      }
    }, 4000);

    return () => {
      clearInterval(setIntFunc); 
    };
  }, []);

  return (
  <>
<div style={{display:'flex',flexDirection:'row',maxHeight:'240px'}}>
{arrayData.map((item, key) => {
        
        return(
        <div className="card" style={{ display:'flex',flexDirection:'column', width: '25%', height: '200px', margin:'20px' }} key={key}>
          <img src={item.Url} style={{height:'200px'}} className="card-img-top" alt={item.altText} />
          <div className="card-body">
            <h5 className="card-title" style={{color:'white'}}><a style={{color:'aliceblue',marginBottom:"50px"}} href={`https://en.wikipedia.org/wiki/${item.Name}`}>{item.Name}</a></h5>
          </div>
          </div>
        )
        }
        )}

</div>
  </>
  )
}

export default Card