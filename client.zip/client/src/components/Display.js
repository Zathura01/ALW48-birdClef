import React from 'react'

function Display({style}) {
  return (
    <>
    <div className='container' style={style}>
        asdffds
    </div>
    
    </>
  )
}

export default Display