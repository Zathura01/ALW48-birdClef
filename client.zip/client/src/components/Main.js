import React from 'react'
import Display from './Display'
import Mic from './Mic'

function Main({style}) {

    const micStyle ={
        width:'10%',
        height:'100%',
        marginLeft:'5px',
        backgroundColor:'white',
     display:'flex',
     flexDirection:'column',
       flexWrap:'nowrap',
       justifyContent: 'space-around'
      }
      
      const displayStyle = {
          width:'90%',
          height:'100%',
          marginRight:'5px'
      }

  return (



    <>
    <div className='container' style={style}>
    <Display style={displayStyle}/>
    <Mic style={micStyle}/>
    </div>
   
    
    </>
  )
}

export default Main