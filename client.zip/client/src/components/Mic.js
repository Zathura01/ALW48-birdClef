import React, { useState } from "react";
import Micro from "../Mic.jpg";
import Camera from "../Camera.jpg";
import "../App.css";

function Mic({ style }) {
  const [micBack, setMicBack] = useState(false);
  const [camBack, setCamBack] = useState(false);

  const [audioChunks, setAudioChunks] = useState([]);
  const [isRecording, setIsRecording] = useState(false);

  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage("Select an audio file.");
      return;
    }

    const formData = new FormData();
    formData.append("audio", file);

    try {
      const response = await fetch("http://localhost:4000/api/upload-audio", {
        method: "POST",
        body: formData,
      });

      if (response.status === 200) {
        setMessage("Done");
      } else {
        setMessage("Error");
      }
    } catch (error) {
      console.error("Error uploading audio:", error);
      setMessage("Error uploading audio.");
    }

    try {
        const responseT = await fetch("http://localhost:5000/server");
        const dataT = await responseT.json();
        console.log(dataT); // Process the fetched data
      } catch (error) {
        console.log("Error connecting to flask:", error);
      }


  };

  const startRecording = () => {
    setIsRecording(true);
    setAudioChunks([]);
    navigator.mediaDevices
      .getUserMedia({ audio: true })
      .then((stream) => {
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            setAudioChunks((chunks) => [...chunks, event.data]);
          }
        };
        mediaRecorder.onstop = () => {
          setIsRecording(false);

          const formData = new FormData();
          const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
          formData.append("audio", audioBlob, "audio.wav");
          console.log(formData);
        };

        

        mediaRecorder.start();
        setTimeout(() => {
          mediaRecorder.stop();
        }, 5000); // Recording for 5 seconds
      })
      .catch((error) => console.error("Error accessing microphone:", error));
  };

  const playRecording = () => {
    const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
    const audioUrl = URL.createObjectURL(audioBlob);
    const audio = new Audio(audioUrl);
    console.log("play", "  ", isRecording);
    audio.play();
  };

  const downloadAudio = () => {
    const currentDate = new Date(Date.now());

    const month = (currentDate.getMonth() + 1).toString().padStart(2, "0"); 
    const day = currentDate.getDate().toString().padStart(2, "0"); 
    const hours = currentDate.getHours().toString().padStart(2, "0"); 
    const minutes = currentDate.getMinutes().toString().padStart(2, "0"); 

    const formattedDateTime = `${month}-${day} ${hours}:${minutes}`;
    const fileName = `${formattedDateTime}_audio.wav`;
    const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
    const audioUrl = URL.createObjectURL(audioBlob);
    const downloadLink = document.createElement("a");
    downloadLink.href = audioUrl;
    downloadLink.download = fileName;

    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  const microphone = async () => {
    //micBack === false ? setMicBack(true) && startRecording() : setMicBack(false) && playRecording();
    if (micBack === false) {
      setMicBack(true);
      startRecording();
    }
    if (micBack === true) {
      setMicBack(false);
      playRecording();
    }
  };

  const camera = () => {
    camBack === false ? setCamBack(true) : setCamBack(false);
  };

  return (
    <>
      <div className="container" style={style}>
        <br />
        <button
          className="mic-button"
          onClick={microphone}
          style={{ marginTop: "10px" }}
        >
          <img
            className="icons"
            src={Micro}
            style={{
              width: "50%",
              height: "70px",
              transform: `scale(${
                micBack === false ? 1 : Math.cos(Date.now() / 100 + 1) * 1.2
              })`,
            }}
          />
        </button>
        <br />
        <br />
        <button className="camera-button" onClick={camera}>
          <img
            className="icons"
            src={Camera}
            style={{
              width: "50%",
              height: "70px",
              transform: `scale(${
                camBack === false ? 1 : Math.cos(Date.now() / 100 + 1) * 1.2
              })`,
            }}
          />
        </button>
        <br></br>
        <br></br>
      </div>
      <div className="container m-auto" style={style}>
        <div style={{marginTop:'20px'}}>
          {" "}
          {(audioChunks.length > 0 && (
            <button onClick={downloadAudio}>Download</button>
          )) || <h4>Waiting..</h4>}
        </div>

        <div className="App">
          <h6>Audio Upload</h6>
          <input
            style={{ width: "90%" }}
            type="file"
            accept=".wav"
            onChange={handleFileChange}
          />
          <br></br>
          <button style={{ width: "80%" }} onClick={handleUpload}>
            Upload
          </button>
          {message && <p>{message}</p>}
        </div>
      </div>
    </>
  );
}

export default Mic;
